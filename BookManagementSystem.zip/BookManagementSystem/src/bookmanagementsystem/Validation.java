/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookmanagementsystem;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ACER
 */
public class Validation {
    
    public static String checkTitle(String title) {
    if (title.isEmpty()) {
        return " cannot be empty";
    }

    for (int i = 0; i < title.length(); i++) {
        char c = title.charAt(i);
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
            return "The title cannot contain special characters or numbers";
        }
    }
    
    return ""; 
    }
    public static String checkPrice(String price) {
    if (price.isEmpty()) {
        return "The age cannot be empty";
    }

    try {
        double d = Double.parseDouble(price);
        if (d <= 0) {
            return "The price must be positive number";
        }
    } catch (NumberFormatException e) {
        return "Wrong input format for age. Please enter a valid number.";
    }

    return ""; 
}
    
    public static String checkAuthor(String author) {
    if (author.isEmpty()) {
        return "The name cannot be empty";
    }

    for (int i = 0; i < author.length(); i++) {
        char c = author.charAt(i);
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
            return "The name cannot contain special characters or numbers";
        }
    }
    
    return ""; 
    }
    
     public static String checkPageNums(String pageNums) {
    if (pageNums.isEmpty()) {
        return "The page numbers cannot be empty";
    }

    try {
        int i = Integer.parseInt(pageNums);
        if (i <= 0) {
            return "The pageNums must be a number bigger than 0";
        }
    } catch (Exception e) {
        return "Wrong input format for page numbers";
    }

    return ""; 
}
    public static String inputUsernamePass(String username, String password){
        if(username.isEmpty() || password.isEmpty()){
            return "Username / Password cannot be empty";
        }
        return "";
    }
    public static String encryptedPassword(String password){
          String result ="";
        try{
            MessageDigest md =MessageDigest.getInstance("Md5");
            byte[] messageDigest = md.digest(password.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);
            result = no.toString(16);
            while(result.length()<32){
                result = "0" + result;
            }
        }  catch (NoSuchAlgorithmException ex) {
            System.out.println("Error!");
            
            
        }
        return result;
    }
    public static String checkName(String name) {
    if (name.isEmpty()) {
        return "The name cannot be empty";
    }

    for (int i = 0; i < name.length(); i++) {
        char c = name.charAt(i);
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ')) {
            return "The name cannot contain special characters or numbers";
        }
    }
    
    return ""; 
    }
    public static String checkAge(String age) {
    if (age.isEmpty()) {
        return "The age cannot be empty";
    }

    try {
        int i = Integer.parseInt(age);
        if (i <= 0) {
            return "The age must be a number bigger than 0";
        }
        if (i > 150) {
            return "The age is too high to be valid";
        }
    } catch (NumberFormatException e) {
        return "Wrong input format for age. Please enter a valid number.";
    }

    return ""; 
}
}
